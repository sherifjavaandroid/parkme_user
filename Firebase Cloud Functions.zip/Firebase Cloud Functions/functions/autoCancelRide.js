const functions = require('firebase-functions');
const admin = require ("firebase-admin");
const firestore = admin.firestore();

/*
** Auto cancel ride after 24 hours
*/
exports.autoCancelRide = functions.pubsub.schedule('0 0 * * *').onRun(async (context) => {

    const dateToMilliSec = admin.firestore.Timestamp.now().toMillis();
    const yesterdayDate = new Date(dateToMilliSec - (24 * 60 * 60 * 1000));

    // Ride cancel for orders
    const ordersSnapshot = await firestore.collection('booked_parking_order').where('status', '==', 'placed').where('bookingEndTime', '<', yesterdayDate).get();
    if(ordersSnapshot.size > 0) {
        ordersSnapshot.forEach(function(doc) {
            const orderData = doc.data();
            if (!orderData) {
                console.log("No order data");
                return;
            }
            console.log('orders : orderId: '+orderData.id);
            firestore.collection('booked_parking_order').doc(orderData.id).update({
                status: "canceled"
            });
            console.log("order status changed successfully");
        });
    }else{
        console.log("No results found for orders");
    }
   
});
